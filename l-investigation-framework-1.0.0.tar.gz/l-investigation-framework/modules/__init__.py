"""Investigation modules for crypto and stegano analysis"""
