"""Full-text search functions"""
from typing import List, Dict, Any
from app.db import execute_query
from app.models import SearchResult

def search_emails(q: str, limit: int = 20) -> List[SearchResult]:
    """Search emails in sources.db using FTS"""
    if not q.strip():
        return []

    query = """
        SELECT
            e.doc_id,
            e.subject,
            e.sender_email as sender,
            snippet(emails_fts, 1, '<mark>', '</mark>', '...', 30) as snippet,
            rank
        FROM emails_fts
        JOIN emails e ON emails_fts.rowid = e.doc_id
        WHERE emails_fts MATCH ?
        ORDER BY rank
        LIMIT ?
    """

    rows = execute_query("sources", query, (q, limit))

    results = []
    for row in rows:
        results.append(SearchResult(
            id=row['doc_id'],
            type='email',
            name=row['subject'] or '(no subject)',
            snippet=row['snippet'],
            score=abs(row['rank'])
        ))

    return results

def search_nodes(q: str, limit: int = 20) -> List[SearchResult]:
    """Search nodes in graph.db using FTS"""
    if not q.strip():
        return []

    query = """
        SELECT
            n.id,
            n.type,
            n.name,
            snippet(nodes_fts, 1, '<mark>', '</mark>', '...', 30) as snippet,
            rank
        FROM nodes_fts
        JOIN nodes n ON nodes_fts.rowid = n.id
        WHERE nodes_fts MATCH ?
        ORDER BY rank
        LIMIT ?
    """

    rows = execute_query("graph", query, (q, limit))

    results = []
    for row in rows:
        results.append(SearchResult(
            id=row['id'],
            type=row['type'],
            name=row['name'],
            snippet=row['snippet'],
            score=abs(row['rank'])
        ))

    return results

def search_all(q: str, limit: int = 20) -> List[SearchResult]:
    """Search both emails and nodes"""
    email_results = search_emails(q, limit // 2)
    node_results = search_nodes(q, limit // 2)

    # Combine and sort by score
    all_results = email_results + node_results
    all_results.sort(key=lambda x: x.score, reverse=True)

    return all_results[:limit]
