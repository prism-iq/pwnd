"""FastAPI routes"""
from fastapi import APIRouter, Query, HTTPException, Request
from fastapi.responses import StreamingResponse
from typing import Optional, List
import json
from datetime import datetime
import uuid

from app.models import (
    SearchResult, QueryRequest, AutoSessionRequest,
    Node, Edge, Score, Flag, LanguageRequest
)
from app.search import search_all, search_emails, search_nodes
from app.db import execute_query, execute_insert, execute_update
from app.pipeline import process_query, auto_investigate

router = APIRouter()

# Health & Stats
@router.get("/api/health")
async def health():
    """Health check"""
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

@router.get("/api/stats")
async def stats():
    """System statistics"""
    nodes_count = execute_query("graph", "SELECT COUNT(*) as c FROM nodes", ())[0]["c"]
    edges_count = execute_query("graph", "SELECT COUNT(*) as c FROM edges", ())[0]["c"]
    emails_count = execute_query("sources", "SELECT COUNT(*) as c FROM emails", ())[0]["c"]

    return {
        "nodes": nodes_count,
        "edges": edges_count,
        "sources": emails_count,
        "databases": ["sources", "graph", "scores", "audit", "sessions"]
    }

@router.get("/api/limits")
async def limits():
    """Get current rate limiting and cost tracking status"""
    from app.rate_limiter import get_limits_status
    from app.cost_tracker import get_today_cost

    rate_limits = get_limits_status()
    cost_stats = get_today_cost()

    return {
        "rate_limiting": rate_limits,
        "cost_tracking": cost_stats,
        "status": "ok" if not cost_stats["budget_exceeded"] else "budget_exceeded"
    }

# Search
@router.get("/api/search", response_model=List[SearchResult])
async def search(q: str = Query(..., max_length=1000), limit: int = Query(20, ge=1, le=100)):
    """Universal search"""
    return search_all(q, limit)

@router.get("/api/search/emails", response_model=List[SearchResult])
async def search_emails_endpoint(q: str = Query(..., max_length=1000), limit: int = Query(20, ge=1, le=100)):
    """Search emails only"""
    return search_emails(q, limit)

@router.get("/api/search/nodes", response_model=List[SearchResult])
async def search_nodes_endpoint(q: str = Query(..., max_length=1000), limit: int = Query(20, ge=1, le=100)):
    """Search nodes only"""
    return search_nodes(q, limit)

@router.get("/api/source/{source_id}")
async def get_source(source_id: int):
    """Get email/source by doc_id"""
    emails = execute_query(
        "sources",
        "SELECT * FROM emails WHERE doc_id = ?",
        (source_id,)
    )
    if not emails:
        raise HTTPException(status_code=404, detail="Source not found")
    return emails[0]

# Graph
@router.get("/api/nodes")
async def get_nodes(type: Optional[str] = None, limit: int = Query(100, ge=1, le=1000)):
    """Get nodes with optional type filter"""
    if type:
        query = "SELECT * FROM nodes WHERE type = ? ORDER BY updated_at DESC LIMIT ?"
        params = (type, limit)
    else:
        query = "SELECT * FROM nodes ORDER BY updated_at DESC LIMIT ?"
        params = (limit,)

    return execute_query("graph", query, params)

@router.get("/api/nodes/{node_id}")
async def get_node(node_id: int):
    """Get single node"""
    nodes = execute_query("graph", "SELECT * FROM nodes WHERE id = ?", (node_id,))
    if not nodes:
        raise HTTPException(status_code=404, detail="Node not found")
    return nodes[0]

@router.get("/api/nodes/{node_id}/edges")
async def get_node_edges(node_id: int):
    """Get all edges for a node"""
    query = """
        SELECT * FROM edges
        WHERE from_node_id = ? OR to_node_id = ?
        ORDER BY created_at DESC
    """
    return execute_query("graph", query, (node_id, node_id))

@router.get("/api/nodes/{node_id}/properties")
async def get_node_properties(node_id: int):
    """Get all properties for a node"""
    return execute_query("graph", "SELECT * FROM properties WHERE node_id = ?", (node_id,))

@router.get("/api/nodes/{node_id}/scores")
async def get_node_scores(node_id: int):
    """Get scores for a node"""
    scores = execute_query("scores", "SELECT * FROM scores WHERE target_type = 'node' AND target_id = ?", (node_id,))
    if not scores:
        return {"target_type": "node", "target_id": node_id, "confidence": 50}
    return scores[0]

@router.get("/api/edges")
async def get_edges(type: Optional[str] = None, limit: int = Query(100, ge=1, le=1000)):
    """Get edges with optional type filter"""
    if type:
        query = "SELECT * FROM edges WHERE type = ? ORDER BY created_at DESC LIMIT ?"
        params = (type, limit)
    else:
        query = "SELECT * FROM edges ORDER BY created_at DESC LIMIT ?"
        params = (limit,)

    return execute_query("graph", query, params)

@router.get("/api/edges/{edge_id}")
async def get_edge(edge_id: int):
    """Get single edge"""
    edges = execute_query("graph", "SELECT * FROM edges WHERE id = ?", (edge_id,))
    if not edges:
        raise HTTPException(status_code=404, detail="Edge not found")
    return edges[0]

# Investigation
@router.get("/api/ask")
async def ask(request: Request, q: str = Query(..., max_length=10000), conversation_id: Optional[str] = None):
    """Main investigation endpoint with SSE streaming"""

    async def event_generator():
        async for event in process_query(q, conversation_id):
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )

# Auto-investigation
@router.post("/api/auto/start")
async def auto_start(request: AutoSessionRequest):
    """Start auto-investigation"""

    async def event_generator():
        async for event in auto_investigate(request.conversation_id, request.max_queries):
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )

@router.post("/api/auto/stop")
async def auto_stop(conversation_id: str):
    """Stop auto-investigation"""
    execute_update(
        "sessions",
        "UPDATE auto_sessions SET status = 'stopped', stopped_at = datetime('now') WHERE conversation_id = ? AND status = 'running'",
        (conversation_id,)
    )
    return {"status": "stopped"}

@router.get("/api/auto/status")
async def auto_status(conversation_id: str):
    """Get auto-investigation status"""
    sessions = execute_query(
        "sessions",
        "SELECT * FROM auto_sessions WHERE conversation_id = ? ORDER BY started_at DESC LIMIT 1",
        (conversation_id,)
    )

    if not sessions:
        return {"running": False}

    session = sessions[0]
    return {
        "running": session["status"] == "running",
        "query_count": session["query_count"],
        "max_queries": session["max_queries"],
        "started_at": session["started_at"]
    }

# Conversations & Settings
@router.get("/api/conversations")
async def get_conversations():
    """Get all conversations"""
    return execute_query("sessions", "SELECT * FROM conversations ORDER BY updated_at DESC", ())

@router.post("/api/conversations")
async def create_conversation(title: str = "New Investigation"):
    """Create new conversation"""
    conv_id = str(uuid.uuid4())
    execute_insert(
        "sessions",
        "INSERT INTO conversations (id, title) VALUES (?, ?)",
        (conv_id, title)
    )
    return {"id": conv_id, "title": title}

@router.get("/api/conversations/{conv_id}/messages")
async def get_messages(conv_id: str):
    """Get messages for conversation"""
    return execute_query(
        "sessions",
        "SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC",
        (conv_id,)
    )

@router.get("/api/settings")
async def get_settings():
    """Get all settings"""
    rows = execute_query("sessions", "SELECT key, value FROM settings", ())
    return {row["key"]: row["value"] for row in rows}

@router.put("/api/settings")
async def update_settings(settings: dict):
    """Update settings"""
    for key, value in settings.items():
        execute_update(
            "sessions",
            "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))",
            (key, str(value))
        )
    return {"status": "updated"}

@router.get("/api/settings/languages")
async def get_languages():
    """Get supported languages"""
    from app.config import SUPPORTED_LANGUAGES
    return {"languages": SUPPORTED_LANGUAGES}

@router.put("/api/settings/language")
async def set_language(request: LanguageRequest):
    """Set UI language"""
    from app.config import SUPPORTED_LANGUAGES
    if request.language not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail=f"Unsupported language. Use: {list(SUPPORTED_LANGUAGES.keys())}")

    execute_update(
        "sessions",
        "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES ('language', ?, datetime('now'))",
        (request.language,)
    )
    return {"status": "updated", "language": request.language}
