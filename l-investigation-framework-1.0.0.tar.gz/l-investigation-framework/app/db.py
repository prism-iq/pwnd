"""Database connections and utilities"""
import sqlite3
from contextlib import contextmanager
from typing import Optional, List, Dict, Any
from app.config import DB_SOURCES, DB_GRAPH, DB_SCORES, DB_AUDIT, DB_SESSIONS

@contextmanager
def get_db(db_name: str):
    """Context manager for database connections"""
    db_map = {
        "sources": DB_SOURCES,
        "graph": DB_GRAPH,
        "scores": DB_SCORES,
        "audit": DB_AUDIT,
        "sessions": DB_SESSIONS
    }

    db_path = db_map.get(db_name)
    if not db_path:
        raise ValueError(f"Unknown database: {db_name}")

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def execute_query(db_name: str, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
    """Execute a SELECT query and return results as list of dicts"""
    with get_db(db_name) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

def execute_update(db_name: str, query: str, params: tuple = ()) -> int:
    """Execute an INSERT/UPDATE/DELETE and return rowcount"""
    with get_db(db_name) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        return cursor.rowcount

def execute_insert(db_name: str, query: str, params: tuple = ()) -> int:
    """Execute an INSERT and return last inserted id"""
    with get_db(db_name) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        return cursor.lastrowid

def init_databases():
    """Initialize databases if needed"""
    # Create sessions.db if not exists
    with get_db("sessions") as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                title TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                is_auto INTEGER DEFAULT 0,
                auto_depth INTEGER DEFAULT 0,
                tokens_in INTEGER,
                tokens_out INTEGER,
                model TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS auto_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                status TEXT DEFAULT 'running',
                query_count INTEGER DEFAULT 0,
                max_queries INTEGER DEFAULT 20,
                started_at TEXT DEFAULT (datetime('now')),
                stopped_at TEXT
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT DEFAULT (datetime('now'))
            );

            INSERT OR IGNORE INTO settings (key, value) VALUES
                ('theme', 'dark'),
                ('auto_max_queries', '20'),
                ('language', 'fr'),
                ('show_confidence', '1'),
                ('show_sources', '1');
        """)
        conn.commit()

    # Create haiku_calls tracking table in audit.db
    with get_db("audit") as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS haiku_calls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tokens_in INTEGER,
                tokens_out INTEGER,
                cost_usd REAL,
                query_preview TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_haiku_calls_date ON haiku_calls(created_at);
        """)
        conn.commit()
