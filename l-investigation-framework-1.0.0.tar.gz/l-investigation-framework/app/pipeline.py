"""Query processing pipeline - 4-step LLM flow"""
import json
from typing import AsyncGenerator, Dict, Any, List
from app.llm_client import call_mistral, call_haiku
from app.search import search_emails, search_nodes
from app.db import execute_query, execute_insert

NL = chr(10)


async def parse_intent_mistral(query: str) -> Dict[str, Any]:
    """Step 1: Mistral IN - Parse query into structured intent (2-3 sec, 100 tokens)"""
    prompt = f"""Parse this query into JSON format. Output ONLY valid JSON, nothing else.

Intent types: "connections" (who knows X), "search" (find about X), "timeline" (chronological)

Examples:
- "who knows trump" -> {{"intent": "connections", "entities": ["trump"], "filters": {{}}}}
- "emails in 2003" -> {{"intent": "search", "entities": [], "filters": {{"date_from": "2003"}}}}

Query: {query}

JSON:"""

    response = await call_mistral(prompt, max_tokens=100, temperature=0.0)

    try:
        # Extract JSON from response (handle markdown code blocks)
        response = response.strip()
        if response.startswith("```"):
            # Remove markdown code fences
            lines = response.split(NL)
            response = NL.join([l for l in lines if not l.startswith("```")])

        intent = json.loads(response.strip())

        # Normalize entities to flat array if Mistral returns nested dict
        # Expected: "entities": ["epstein", "jeffrey"]
        # Actual from Mistral: "entities": {"person": ["Jeffrey Epstein", "who"]}
        entities = intent.get("entities", [])
        if isinstance(entities, dict):
            # Flatten nested dict to array
            flat_entities = []
            for value in entities.values():
                if isinstance(value, list):
                    flat_entities.extend(value)
                elif isinstance(value, str):
                    flat_entities.append(value)
            intent["entities"] = flat_entities

        return intent
    except json.JSONDecodeError as e:
        # Fallback to search if parsing fails
        return {"intent": "search", "entities": [], "filters": {}}


def execute_sql_by_intent(intent: Dict[str, Any], limit: int = 10) -> List[Dict[str, Any]]:
    """Step 2: Python SQL - Execute queries based on intent type"""
    intent_type = intent.get("intent", "search")
    entities = intent.get("entities", [])
    filters = intent.get("filters", {})

    results = []

    if intent_type == "search":
        # FTS search in sources.db and graph.db
        search_term = " ".join(entities) if entities else ""

        # Only search if we have a search term
        if search_term.strip():
            # Search emails
            email_query = """
                SELECT
                    e.doc_id as id,
                    'email' as type,
                    e.subject as name,
                    e.sender_email,
                    e.recipients_to,
                    e.date_sent as date,
                    snippet(emails_fts, 1, '<mark>', '</mark>', '...', 50) as snippet,
                    rank
                FROM emails_fts
                JOIN emails e ON emails_fts.rowid = e.doc_id
                WHERE emails_fts MATCH ?
                ORDER BY rank
                LIMIT ?
            """
            email_results = execute_query("sources", email_query, (search_term, limit // 2))
            results.extend(email_results)

            # Search nodes in graph.db (using LIKE for partial matches)
            node_query = """
                SELECT
                    n.id,
                    n.type,
                    n.name,
                    n.source_db,
                    n.source_id
                FROM nodes n
                WHERE LOWER(n.name) LIKE LOWER(?) OR LOWER(n.name_normalized) LIKE LOWER(?)
                LIMIT ?
            """
            search_pattern = f"%{search_term}%"
            node_results = execute_query("graph", node_query, (search_pattern, search_pattern, limit // 2))

            # For each node found, get linked emails from sources.db
            for node in node_results:
                if node.get("source_db") == "sources" and node.get("source_id"):
                    # Fetch the email from sources.db
                    linked_email_query = """
                        SELECT
                            doc_id as id,
                            'email' as type,
                            subject as name,
                            sender_email,
                            recipients_to,
                            date_sent as date,
                            substr(body_text, 1, 200) as snippet
                        FROM emails
                        WHERE doc_id = ?
                        LIMIT 1
                    """
                    linked_emails = execute_query("sources", linked_email_query, (node["source_id"],))
                    results.extend(linked_emails)

            # Add nodes themselves to results (with snippet as name for display)
            for node in node_results:
                results.append({
                    "id": node["id"],
                    "type": node["type"],
                    "name": node["name"],
                    "snippet": f"{node['type']}: {node['name']}"
                })

    elif intent_type == "connections":
        # Query edges where entity matches
        if entities:
            entity_pattern = f"%{entities[0]}%"

            # Find nodes matching entity
            node_query = """
                SELECT id, type, name
                FROM nodes
                WHERE name LIKE ? OR name_normalized LIKE ?
                LIMIT 5
            """
            nodes = execute_query("graph", node_query, (entity_pattern, entity_pattern))

            if nodes:
                node_ids = [n["id"] for n in nodes]
                placeholders = ",".join(["?"] * len(node_ids))

                # Get connections
                edge_query = f"""
                    SELECT
                        e.id,
                        e.type as edge_type,
                        n1.name as from_name,
                        n1.type as from_type,
                        n2.name as to_name,
                        n2.type as to_type,
                        e.excerpt
                    FROM edges e
                    JOIN nodes n1 ON e.from_node_id = n1.id
                    JOIN nodes n2 ON e.to_node_id = n2.id
                    WHERE e.from_node_id IN ({placeholders}) OR e.to_node_id IN ({placeholders})
                    LIMIT ?
                """
                edge_results = execute_query("graph", edge_query, (*node_ids, *node_ids, limit))
                results.extend(edge_results)

                # Also search for related emails if we have entities
                if entities:
                    search_term = " ".join(entities)
                    email_query = """
                        SELECT
                            e.doc_id as id,
                            'email' as type,
                            e.subject as name,
                            e.sender_email,
                            e.recipients_to,
                            e.date_sent as date,
                            snippet(emails_fts, 1, '<mark>', '</mark>', '...', 50) as snippet,
                            rank
                        FROM emails_fts
                        JOIN emails e ON emails_fts.rowid = e.doc_id
                        WHERE emails_fts MATCH ?
                        ORDER BY rank
                        LIMIT ?
                    """
                    email_results = execute_query("sources", email_query, (search_term, limit))
                    results.extend(email_results)

    elif intent_type == "timeline":
        # Query ordered by date
        date_from = filters.get("date_from")

        if date_from:
            query = """
                SELECT
                    doc_id as id,
                    'email' as type,
                    subject as name,
                    sender_email,
                    recipients_to,
                    date_sent as date,
                    substr(body_text, 1, 200) as snippet
                FROM emails
                WHERE date_sent >= ?
                ORDER BY date_sent ASC
                LIMIT ?
            """
            results = execute_query("sources", query, (date_from, limit))
        else:
            query = """
                SELECT
                    doc_id as id,
                    'email' as type,
                    subject as name,
                    sender_email,
                    recipients_to,
                    date_sent as date,
                    substr(body_text, 1, 200) as snippet
                FROM emails
                ORDER BY date_sent DESC
                LIMIT ?
            """
            results = execute_query("sources", query, (limit,))

    return results[:limit]


async def analyze_haiku(query: str, sql_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Step 3: Haiku - Smart analysis returning compact JSON (300 tokens max)"""
    from app.cost_tracker import check_budget_available, record_haiku_call, get_fallback_response

    if not sql_results:
        return {
            "findings": [],
            "sources": [],
            "confidence": "low",
            "hypotheses": [],
            "contradictions": [],
            "suggested_queries": []
        }

    # Check budget before calling Haiku
    budget_ok, budget_reason = check_budget_available()
    if not budget_ok:
        # Return fallback response
        return get_fallback_response()

    # Format SQL results for Haiku
    results_text = []
    source_ids = []

    for i, result in enumerate(sql_results[:10], 1):
        result_type = result.get("type", "unknown")
        source_ids.append(result.get("id", 0))

        if result_type == "email":
            results_text.append(
                f"[{i}] Email #{result.get('id')}: {result.get('name', 'No subject')}\n"
                f"    From: {result.get('sender_email', 'N/A')} | Date: {result.get('date', 'N/A')}\n"
                f"    {result.get('snippet', '')}"
            )
        else:
            results_text.append(
                f"[{i}] {result_type} #{result.get('id')}: {result.get('name', 'N/A')}\n"
                f"    {result.get('snippet', '')}"
            )

    data_block = NL.join(results_text)

    prompt = f"""Analyze for pwnd.icu investigation. Return ONLY JSON.

Question: {query}
Data:
{data_block}

Format:
{{"findings": ["fact1", "fact2"], "sources": [123, 456], "confidence": "high|medium|low", "hypotheses": ["maybe X"], "contradictions": [], "suggested_queries": ["dig into Y"]}}"""

    haiku_response = await call_haiku(prompt, max_tokens=300)

    if "error" in haiku_response:
        # Fallback if Haiku fails
        return {
            "findings": [f"Found {len(sql_results)} results"],
            "sources": source_ids[:5],
            "confidence": "medium",
            "hypotheses": [],
            "contradictions": [],
            "suggested_queries": []
        }

    try:
        # Record the cost
        usage = haiku_response.get("usage", {})
        if usage:
            tokens_in = usage.get("input_tokens", 0)
            tokens_out = usage.get("output_tokens", 0)
            record_haiku_call(tokens_in, tokens_out)

        analysis = json.loads(haiku_response.get("text", "{}"))
        return analysis
    except json.JSONDecodeError:
        # Fallback
        return {
            "findings": [f"Found {len(sql_results)} results"],
            "sources": source_ids[:5],
            "confidence": "medium",
            "hypotheses": [],
            "contradictions": [],
            "suggested_queries": []
        }


async def format_response_mistral(query: str, haiku_json: Dict[str, Any]) -> str:
    """Step 4: Mistral OUT - Format analysis as natural response (512 tokens, temp 0.7)"""
    analysis_json = json.dumps(haiku_json, indent=2, ensure_ascii=False)

    prompt = f"""You are the pwnd.icu investigator. Format this analysis as a natural response.

User asked: {query}
Analysis: {analysis_json}

Rules:
- Respond in user's language
- Cite sources as [#ID]
- Mention confidence level
- Be direct but can have subtle humor
- If hypotheses exist, present them clearly
- End with suggested next queries if relevant"""

    response = await call_mistral(prompt, max_tokens=512, temperature=0.7)
    return response


async def process_query(query: str, conversation_id: str = None) -> AsyncGenerator[Dict[str, Any], None]:
    """Main query processing pipeline - 4-step LLM flow"""

    # STEP 1: Mistral IN - Parse intent (2-3 sec)
    yield {"type": "status", "msg": "Parsing query..."}

    intent = await parse_intent_mistral(query)
    yield {"type": "debug", "intent": intent}  # Debug info

    # STEP 2: Python SQL - Execute queries (fast)
    yield {"type": "status", "msg": f"Executing {intent.get('intent', 'search')} query..."}

    try:
        sql_results = execute_sql_by_intent(intent, limit=10)
        yield {"type": "debug", "sql_results_count": len(sql_results)}
    except Exception as e:
        yield {"type": "error", "msg": f"SQL error: {str(e)}"}
        yield {"type": "done"}
        return

    if not sql_results:
        yield {"type": "chunk", "text": "No relevant sources found."}
        yield {"type": "done"}
        return

    # Send source IDs to frontend
    source_ids = [r.get("id", 0) for r in sql_results]
    yield {"type": "sources", "ids": source_ids}

    # STEP 3: Haiku - Smart analysis (COMPACT, 300 tokens)
    yield {"type": "status", "msg": "Analyzing with Haiku..."}

    haiku_analysis = await analyze_haiku(query, sql_results)
    yield {"type": "debug", "haiku_analysis": haiku_analysis}  # Debug info

    # STEP 4: Mistral OUT - Natural response formatting (can take 30-60s)
    yield {"type": "status", "msg": "Formatting response..."}

    final_response = await format_response_mistral(query, haiku_analysis)

    # Stream the final response
    yield {"type": "chunk", "text": final_response}

    # Send hypotheses if any
    if haiku_analysis.get("hypotheses"):
        yield {"type": "updates", "changes": haiku_analysis["hypotheses"]}

    # Done
    yield {"type": "done"}

async def auto_investigate(conversation_id: str, max_queries: int = 20) -> AsyncGenerator[Dict[str, Any], None]:
    """Auto-investigation mode - LLM generates follow-up questions"""

    # Get last user message
    messages = execute_query(
        "sessions",
        "SELECT content FROM messages WHERE conversation_id = ? AND role = 'user' ORDER BY created_at DESC LIMIT 1",
        (conversation_id,)
    )

    if not messages:
        yield {"type": "error", "msg": "No user message found"}
        return

    initial_query = messages[0]["content"]

    # Create auto session
    session_id = execute_insert(
        "sessions",
        "INSERT INTO auto_sessions (conversation_id, max_queries) VALUES (?, ?)",
        (conversation_id, max_queries)
    )

    query_count = 0
    current_query = initial_query

    while query_count < max_queries:
        query_count += 1

        yield {"type": "status", "msg": f"Auto-query {query_count}/{max_queries}"}

        # Process current query
        async for event in process_query(current_query, conversation_id):
            yield event

        # Generate next question using Mistral
        next_prompt = f"""Based on the investigation so far, generate ONE follow-up question to dig deeper.{NL}{NL}Previous question: {current_query}{NL}{NL}Next question (one line only):"""

        next_query = await call_mistral(next_prompt, max_tokens=128)

        if not next_query or len(next_query) < 10:
            break

        current_query = next_query.strip()

        # Update session
        execute_query(
            "sessions",
            "UPDATE auto_sessions SET query_count = ? WHERE id = ?",
            (query_count, session_id)
        )

    # Mark session complete
    execute_query(
        "sessions",
        "UPDATE auto_sessions SET status = 'completed', stopped_at = datetime('now') WHERE id = ?",
        (session_id,)
    )

    yield {"type": "auto_complete", "total_queries": query_count}
