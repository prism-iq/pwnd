# pwnd.icu - OSINT Investigation Framework

Professional OSINT investigation framework powered by graph analysis and AI-driven insights.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## Features

- **📧 Email Analysis**: Full-text search across 13,009+ indexed emails
- **🕸️ Graph Database**: Entity relationship mapping and connection discovery
- **🤖 AI-Powered**: Mistral 7B for intent parsing + Claude Haiku for deep analysis
- **🔄 Auto-Investigation**: Automatically chains suggested queries
- **📊 Real-time Streaming**: Server-Sent Events (SSE) for live updates
- **🎨 Modern UI**: Professional dark theme with markdown rendering
- **📱 Responsive**: Works on desktop, tablet, and mobile

## Architecture

```
┌─────────────┐
│   Browser   │
│  (React-ish)│
└──────┬──────┘
       │ SSE Stream
       ▼
┌─────────────┐      ┌──────────────┐
│  FastAPI    │◄────►│   Mistral    │
│   (API)     │      │  (Intent)    │
└──────┬──────┘      └──────────────┘
       │
       ├──────────────┐
       ▼              ▼
┌─────────────┐  ┌──────────────┐
│  SQLite     │  │   Claude     │
│ (3 DBs)     │  │   Haiku      │
│             │  │  (Analysis)  │
│ • sources   │  └──────────────┘
│ • graph     │
│ • sessions  │
└─────────────┘
```

## Installation

### Prerequisites

- **OS**: Linux (Arch, Ubuntu, Debian)
- **Python**: 3.10+
- **RAM**: 8GB+ (for Mistral LLM)
- **Storage**: 5GB+ (for databases)

### Quick Start

```bash
# Clone the repository
git clone https://github.com/yourusername/pwnd-icu.git
cd pwnd-icu

# Run setup script (as root)
sudo chmod +x setup.sh
sudo ./setup.sh
```

The setup script will:
1. Install system dependencies
2. Create Python virtual environment
3. Install Python packages
4. Initialize databases
5. Create systemd services
6. Configure Nginx reverse proxy

### Manual Installation

If you prefer manual setup:

```bash
# 1. Create virtual environment
python3 -m venv venv
source venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Initialize databases
sqlite3 db/sessions.db < db/schema_sessions.sql

# 4. Start services
# Terminal 1: Start Mistral LLM backend
python backend.py

# Terminal 2: Start FastAPI
uvicorn app.main:app --host 127.0.0.1 --port 8002

# 5. Configure Nginx (see setup.sh for config)
```

## Configuration

### Environment Variables

Create a `.env` file:

```bash
# API Configuration
HAIKU_API_KEY=your_anthropic_api_key_here
HAIKU_API_URL=https://api.anthropic.com/v1/messages

# LLM Configuration
LLM_MISTRAL_URL=http://127.0.0.1:8001/generate

# Database Paths
DB_SOURCES=/opt/rag/db/sources.db
DB_GRAPH=/opt/rag/db/graph.db
DB_SESSIONS=/opt/rag/db/sessions.db
DB_SCORES=/opt/rag/db/scores.db
DB_AUDIT=/opt/rag/db/audit.db

# Rate Limiting
MAX_CONCURRENT_QUERIES=10
MAX_QUERIES_PER_HOUR=100
MAX_QUERIES_PER_DAY=500

# Cost Protection
HAIKU_DAILY_BUDGET_USD=5.00
```

### Database Setup

#### 1. Sources Database (`sources.db`)
Contains email data with FTS (Full-Text Search):

```sql
-- Import your email data
-- Schema: emails table with FTS index
```

#### 2. Graph Database (`graph.db`)
Entity relationships and connections:

```sql
-- Schema: nodes, edges, properties tables
-- Build from email data using entity extraction
```

#### 3. Sessions Database (`sessions.db`)
User conversations and settings:

```sql
-- Auto-created by setup script
-- Schema: conversations, messages, settings
```

## Usage

### Web Interface

1. Open browser: `http://localhost` or `https://pwnd.icu`
2. Ask a question: "Who is Jeffrey Epstein?"
3. View sources: Click `[#ID]` to see full email
4. Enable auto-investigate: Toggle for automatic query chaining

### API Endpoints

#### Query Investigation
```bash
curl "http://localhost/api/ask?q=trump+connections"
```

#### Get Source
```bash
curl "http://localhost/api/source/123"
```

#### System Stats
```bash
curl "http://localhost/api/stats"
```

#### Rate Limits
```bash
curl "http://localhost/api/limits"
```

### Auto-Investigation Mode

Enable the toggle to automatically chain queries:

1. Initial query: "Who is Jeffrey Epstein?"
2. AI suggests: "Retrieve comprehensive biographical sources"
3. Auto-runs suggested query
4. Continues until max queries (default: 20)

## Project Structure

```
pwnd-icu/
├── app/
│   ├── main.py              # FastAPI application
│   ├── routes.py            # API endpoints
│   ├── pipeline.py          # 4-step LLM pipeline
│   ├── llm_client.py        # Mistral + Haiku clients
│   ├── db.py                # Database utilities
│   ├── search.py            # FTS search functions
│   ├── models.py            # Pydantic models
│   ├── config.py            # Configuration
│   ├── rate_limiter.py      # Rate limiting
│   └── cost_tracker.py      # API cost tracking
├── static/
│   ├── index.html           # Frontend HTML
│   ├── app.js               # Frontend JavaScript
│   └── style.css            # Frontend CSS
├── db/
│   ├── sources.db           # Email database (not included)
│   ├── graph.db             # Graph database (not included)
│   ├── sessions.db          # User sessions
│   └── schema_sessions.sql  # Sessions schema
├── backend.py               # Mistral LLM server
├── setup.sh                 # Installation script
├── requirements.txt         # Python dependencies
└── README.md                # This file
```

## Development

### Running in Development

```bash
# Start with auto-reload
uvicorn app.main:app --reload --host 127.0.0.1 --port 8002
```

### Testing

```bash
# Test SSE streaming
curl -N "http://127.0.0.1:8002/api/ask?q=test"

# Test source API
curl "http://127.0.0.1:8002/api/source/1"

# Test stats
curl "http://127.0.0.1:8002/api/stats"
```

## System Requirements

### Minimum
- 4 CPU cores
- 8GB RAM
- 5GB storage
- Ubuntu 20.04+

### Recommended
- 8+ CPU cores
- 16GB+ RAM
- 50GB+ SSD storage
- Arch Linux / Ubuntu 22.04+

## Performance

- **Query latency**: 2-5 seconds (Mistral + Haiku)
- **SSE streaming**: Real-time chunks
- **Concurrent users**: 10 (configurable)
- **Database**: SQLite FTS5 (fast search)

## Security

- Rate limiting per IP
- Cost tracking and budgets
- HTML escaping in source viewer
- CORS protection
- HTTPS via Nginx + Let's Encrypt

## Troubleshooting

### Service not starting
```bash
sudo journalctl -u l-api -n 50
sudo journalctl -u l-llm -n 50
```

### Database errors
```bash
# Check database exists
ls -lh db/*.db

# Test database
sqlite3 db/sources.db "SELECT COUNT(*) FROM emails"
```

### LLM timeouts
```bash
# Increase timeout in llm_client.py
httpx.Client(timeout=180.0)  # Default: 3 minutes
```

## License

MIT License - see LICENSE file

## Credits

- **LLMs**: Mistral 7B (local), Claude Haiku (API)
- **Frontend**: Vanilla JS + Marked.js
- **Backend**: FastAPI + SQLite
- **Styling**: Custom CSS (inspired by ChatGPT/Linear/Vercel)

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## Support

- Issues: GitHub Issues
- Docs: This README
- Contact: your@email.com

---

**Built with ❤️ for OSINT investigators**
